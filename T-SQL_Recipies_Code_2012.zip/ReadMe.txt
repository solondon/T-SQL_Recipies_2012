Welcome! You have just opened the ReadMe file for the example source code archive for the following book:

	SQL Server 2012 T-SQL Recipes
	by Jason Brimhall, David Dye, Timothy Roberts, Wayne Sheffield, Jonathan Gennick
	978-1430242000

Source code is organized in .sql files by chapter. For example, the solution snippets from chapter 1 are in the file ch01.sql. 

Enjoy the examples!